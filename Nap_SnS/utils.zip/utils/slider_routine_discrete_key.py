# --- Import packages ---
from psychopy import prefs
from psychopy import plugins
from psychopy import core
from psychopy.constants import (NOT_STARTED, FINISHED)
from psychopy.hardware import keyboard

plugins.activatePlugins()
prefs.hardware['audioLib'] = ['sounddevice', 'PTB', 'pyo', 'pygame'] #'ptb'
prefs.hardware['audioLatencyMode'] = '0'

defaultKeyboard = keyboard.Keyboard(backend='psychotoolbox')

def slider_routine_discrete_key(win, slider, slider_shape, 
                slider_orientation, slider_ticks, slider_granularity, slider_shape_width,
                   slider_decimals, oldRating, text_above_slider,end_key_name):

    frameTolerance = 0.001
    trialClock = core.Clock()
    continueRoutine = True
    mykb = keyboard.Keyboard()

    slider_data = []
    final_rating = None
    final_rt = None
    rating_confirmed = False
    # Define keys and mapping
    key_to_rating = {'d': 1, 'f': 2, 'g': 3, 'h': 4, 'j': 5}
    keyList = list(key_to_rating.keys()) + [end_key_name]

    slider.reset()

    if oldRating is not None:
        slider.markerPos = oldRating
    else:
        slider.markerPos = None

    trialComponents = [slider_shape, slider, text_above_slider]
    for thisComponent in trialComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED

    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    trialClock.reset(-_timeToFirstFrame)
    frameN = -1

    while continueRoutine:
        t = trialClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=trialClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN += 1

        keys = mykb.getKeys(keyList=keyList, waitRelease=False, clear=False)
        for key in keys:
            k = key.name
            if k in key_to_rating:
                rating_value = key_to_rating[k]
                slider.markerPos = rating_value
                final_rating = rating_value
                final_rt = key.rt  # RT from key press
            elif k == end_key_name and slider.markerPos is not None:
                slider.marker.color = 'red'
                win.flip()  # render the red marker at least once
                core.wait(0.1)  # wait a moment so the color change is visible
                rating_confirmed = True 
                continueRoutine = False

        # Component draw logic
        if slider_shape.status == NOT_STARTED and tThisFlip >= 0.0 - frameTolerance:
            slider_shape.frameNStart = frameN
            slider_shape.tStart = t
            slider_shape.tStartRefresh = tThisFlipGlobal
            win.timeOnFlip(slider_shape, 'tStartRefresh')

        if text_above_slider.status == NOT_STARTED and tThisFlip >= 0.0 - frameTolerance:
            text_above_slider.frameNStart = frameN
            text_above_slider.tStart = t
            text_above_slider.tStartRefresh = tThisFlipGlobal
            win.timeOnFlip(text_above_slider, 'tStartRefresh')
            text_above_slider.setAutoDraw(True)

        if slider.status == NOT_STARTED and tThisFlip >= 0.0 - frameTolerance:
            slider.frameNStart = frameN
            slider.tStart = t
            slider.tStartRefresh = tThisFlipGlobal
            win.timeOnFlip(slider, 'tStartRefresh')
            slider.setAutoDraw(True)

        if defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()

        if not continueRoutine:
            break

        continueRoutine = False
        for thisComponent in trialComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break

        if continueRoutine:
            win.flip()

    for thisComponent in trialComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)

    print('Final Response:', final_rating)
    print('Final RT (s):', final_rt)
    print('slider.response:', slider.getRating())
    print('slider.rt:', final_rt)

    return slider, [[final_rating, final_rt if final_rt is not None else None]]

