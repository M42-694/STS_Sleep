# --- Import packages ---
from psychopy import prefs
from psychopy import plugins
from psychopy import core
from psychopy.constants import (NOT_STARTED, FINISHED)
from psychopy.hardware import keyboard
from psychopy import sound

import threading
import time

from psychopy import core, visual, event

plugins.activatePlugins()
prefs.hardware['audioLib'] = ['sounddevice', 'PTB', 'pyo', 'pygame'] #'ptb'
prefs.hardware['audioLatencyMode'] = '0'

defaultKeyboard = keyboard.Keyboard(backend='psychotoolbox')

class Clock:
    def __init__(self):
        self.start_time = time.time()
    def getTime(self):
        return time.time() - self.start_time

def play_sound_rep(file, volume, n_repeat, gap, wait_time):
    time.sleep(wait_time)
    mySound = sound.Sound(file, volume=volume)	
    for r in range(n_repeat):
        repClock = Clock()
        cur_sound_start = repClock.getTime()
        mySound.play()
        while True:
            if repClock.getTime() > cur_sound_start + mySound.getDuration() + gap:
                break
            time.sleep(0.1)

def slider_routine_continuous_key(win, slider, slider_shape,
            slider_orientation, slider_ticks, slider_decimals,
            mySound_file, n_repeat, record_after, rep_interval_cross_sound, gap_time, volume, above_text):

    frameTolerance = 0.001
    trialClock = core.Clock()
    continueRoutine = True

    mykb = keyboard.Keyboard()

    # Reset slider
    slider.reset()
    slider.markerPos = None
    slider_data = []

    # Rating keys
    key_to_rating = {'d': 1, 'f': 2, 'g': 3, 'h': 4, 'j': 5}
    keyList = list(key_to_rating.keys())

    # Prepare sound playback
    sound_thread = threading.Thread(
        target=play_sound_rep,
        args=(mySound_file, volume, n_repeat, gap_time, rep_interval_cross_sound)
    )
    sound_thread.daemon = True
    mySound_rep = sound.Sound(mySound_file, preBuffer=-1, volume=volume)
    sound_thread.start()

    total_duration = (mySound_rep.getDuration() + gap_time) * n_repeat + record_after + rep_interval_cross_sound

    trialComponents = [slider_shape, slider, above_text]
    for thisComponent in trialComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED

    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    trialClock.reset(-_timeToFirstFrame)
    frameN = -1

    first_rating = None
    first_rt = None
    final_rating = None
    final_rt = None

    while continueRoutine:
        t = trialClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=trialClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN += 1

        # Listen for d/f/g/h/j
        keys = mykb.getKeys(keyList=keyList, waitRelease=False, clear=False)
        for key in keys:
            k = key.name
            if k in key_to_rating:
                rating_value = key_to_rating[k]
                slider.markerPos = rating_value

                rt = key.rt
                current_data = [rating_value, rt]
                slider_data.append(current_data)

                # Record first response
                if first_rating is None:
                    first_rating = rating_value
                    first_rt = rt

                # Always update last response
                final_rating = rating_value
                final_rt = rt

        # End routine after full playback
        if t > total_duration:
            continueRoutine = False

        # Component draw
        for component in trialComponents:
            if component.status == NOT_STARTED and tThisFlip >= 0.0 - frameTolerance:
                component.frameNStart = frameN
                component.tStart = t
                component.tStartRefresh = tThisFlipGlobal
                win.timeOnFlip(component, 'tStartRefresh')
                component.setAutoDraw(True)

        if defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()

        if not continueRoutine:
            break

        continueRoutine = False
        for thisComponent in trialComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break

        if continueRoutine:
            win.flip()

    # Cleanup
    for thisComponent in trialComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)

    print('All Responses:', slider_data)
    print('First Response:', first_rating, 'RT:', first_rt)
    print('Final Response:', final_rating, 'RT:', final_rt)

    return slider, slider_data, {
        'first_rating': first_rating,
        'first_rt': first_rt if first_rt is not None else None,
        'final_rating': final_rating,
        'final_rt': final_rating if final_rt is not None else None
    }
