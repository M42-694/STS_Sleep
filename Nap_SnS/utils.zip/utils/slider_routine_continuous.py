# --- Import packages ---
from psychopy import prefs
from psychopy import plugins
from psychopy import core
from psychopy.constants import (NOT_STARTED, FINISHED)
from psychopy.hardware import keyboard
from psychopy import sound

import threading
import time

plugins.activatePlugins()
prefs.hardware['audioLib'] = ['sounddevice', 'PTB', 'pyo', 'pygame'] #'ptb'
prefs.hardware['audioLatencyMode'] = '0'

defaultKeyboard = keyboard.Keyboard(backend='psychotoolbox')

class Clock:
    def __init__(self):
        self.start_time = time.time()
    def getTime(self):
        return time.time() - self.start_time

def play_sound_rep(file, volume, n_repeat, gap, wait_time):
    time.sleep(wait_time)
    for r in range(n_repeat):
        mySound = sound.Sound(file, volume=volume)	
        repClock = Clock()
        cur_sound_start = repClock.getTime()
        mySound.play()
        while True:
            if repClock.getTime() > cur_sound_start + mySound.getDuration() + gap:
                break
            time.sleep(0.1)

def slider_routine_continuous(win, slider, slider_shape, 
            slider_orientation, slider_ticks, slider_granularity, slider_shape_width,
            slider_decimals, sliding, slideSpeed, oldRating, mouse,
            mySound_file, n_repeat, record_after, rep_interval_cross_sound, gap_time, initial_mouse_pos, initial_marker_pos, volume):

    frameTolerance = 0.001
    trialClock = core.Clock()
    continueRoutine = True

    # Initialize keyboard
    mykb = keyboard.Keyboard()

    # Define allowed key responses
    key_to_rating = {'d': 1, 'f': 2, 'g': 3, 'h': 4, 'j': 5}
    keyList = list(key_to_rating.keys())
    slider_data = []

    # Set initial marker as None (hide circle)
    slider.reset()
    slider.markerPos = None
    mouse.setPos(initial_mouse_pos)
    mouseRec = mouse.getPos()

    # Estimate total playback duration
    mySound_rep = sound.Sound(mySound_file, preBuffer=-1, volume=volume)
    total_duration = (mySound_rep.getDuration() + gap_time) * n_repeat + record_after + rep_interval_cross_sound

    # Start background sound thread
    sound_thread = threading.Thread(
        target=play_sound_rep,
        args=(mySound_file, volume, n_repeat, gap_time, rep_interval_cross_sound)
    )
    sound_thread.daemon = True
    sound_thread.start()

    # Track components
    trialComponents = [slider_shape, slider]
    for thisComponent in trialComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED

    # Reset clock
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    trialClock.reset(-_timeToFirstFrame)
    frameN = -1

    # Run routine
    while continueRoutine:
        t = trialClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=trialClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN += 1

        # Check keypresses for rating
        keys = mykb.getKeys(keyList=keyList, waitRelease=False, clear=False)
        if keys:
            key = keys[-1].name
            if key in key_to_rating:
                rating_value = key_to_rating[key]
                slider.markerPos = rating_value
                current_data = [rating_value, int(t * 1000)]
                if len(slider_data) == 0 or slider_data[-1][0] != rating_value:
                    slider_data.append(current_data)

        # End routine only after sound playback and intervals
        if t > total_duration:
            continueRoutine = False

        # Component drawing
        if slider_shape.status == NOT_STARTED and tThisFlip >= 0.0 - frameTolerance:
            slider_shape.frameNStart = frameN
            slider_shape.tStart = t
            slider_shape.tStartRefresh = tThisFlipGlobal
            win.timeOnFlip(slider_shape, 'tStartRefresh')
            slider_shape.setAutoDraw(True)

        if slider.status == NOT_STARTED and tThisFlip >= 0.0 - frameTolerance:
            slider.frameNStart = frameN
            slider.tStart = t
            slider.tStartRefresh = tThisFlipGlobal
            win.timeOnFlip(slider, 'tStartRefresh')
            slider.setAutoDraw(True)

        if defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()

        # Routine end logic
        if not continueRoutine:
            break

        continueRoutine = False
        for thisComponent in trialComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break

        if continueRoutine:
            win.flip()

    # Cleanup
    for thisComponent in trialComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)

    print('All Responses:', slider_data)
    print('Final Response:', slider_data[-1][0] if slider_data else None)
    print('slider.response:', slider.getRating())
    print('slider.rt:', slider.getRT())

    return slider, slider_data
